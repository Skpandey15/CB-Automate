"""
cb-python-embedder
==================
FastAPI microservice that generates 3072-dimensional text embeddings
using OpenAI text-embedding-3-large.

Endpoints:
  POST /embed          — embed a single text string
  POST /embed/batch    — embed a list of text strings (max 100)
  GET  /health         — liveness probe
  GET  /metrics        — Prometheus metrics (via prometheus_client)

Environment variables:
  OPENAI_API_KEY       — required (injected from HashiCorp Vault via k8s secret)
  EMBEDDING_MODEL      — default: text-embedding-3-large
  EMBEDDING_DIMENSIONS — default: 3072 (max for text-embedding-3-large)
  MAX_BATCH_SIZE       — default: 100
  LOG_LEVEL            — default: INFO
"""

from __future__ import annotations

import logging
import os
import time
from contextlib import asynccontextmanager
from typing import Any

import httpx
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from openai import AsyncOpenAI
from prometheus_client import (
    Counter,
    Gauge,
    Histogram,
    generate_latest,
    CONTENT_TYPE_LATEST,
)
from pydantic import BaseModel, Field, field_validator
from starlette.responses import Response

# ─── Logging ─────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger("cb-embedder")

# ─── Config ──────────────────────────────────────────────────────────────────

OPENAI_API_KEY        = os.getenv("OPENAI_API_KEY", "")
EMBEDDING_MODEL       = os.getenv("EMBEDDING_MODEL", "text-embedding-3-large")
EMBEDDING_DIMENSIONS  = int(os.getenv("EMBEDDING_DIMENSIONS", "3072"))
MAX_BATCH_SIZE        = int(os.getenv("MAX_BATCH_SIZE", "100"))
MAX_TOKENS_PER_TEXT   = 8191  # model limit

# ─── Prometheus Metrics ───────────────────────────────────────────────────────

embed_requests   = Counter("cb_embed_requests_total", "Total embedding requests", ["status"])
embed_duration   = Histogram("cb_embed_duration_seconds", "Embedding latency",
                              buckets=[0.1, 0.25, 0.5, 1.0, 2.0, 5.0])
embed_tokens     = Counter("cb_embed_tokens_total", "Total tokens sent to OpenAI")
batch_size_gauge = Gauge("cb_embed_batch_size", "Last batch size processed")
openai_errors    = Counter("cb_openai_errors_total", "OpenAI API errors", ["error_type"])

# ─── Pydantic Schemas ─────────────────────────────────────────────────────────

class EmbedRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=32_000,
                      description="Text to embed (max ~8k tokens)")
    model: str = Field(default=EMBEDDING_MODEL)
    dimensions: int = Field(default=EMBEDDING_DIMENSIONS, ge=256, le=3072)

class EmbedResponse(BaseModel):
    embedding: list[float]
    model: str
    dimensions: int
    tokens_used: int
    latency_ms: float

class BatchEmbedRequest(BaseModel):
    texts: list[str] = Field(..., min_length=1, max_length=MAX_BATCH_SIZE)
    model: str = Field(default=EMBEDDING_MODEL)
    dimensions: int = Field(default=EMBEDDING_DIMENSIONS, ge=256, le=3072)

    @field_validator("texts")
    @classmethod
    def validate_texts(cls, v: list[str]) -> list[str]:
        if any(not t or not t.strip() for t in v):
            raise ValueError("All texts must be non-empty strings")
        return v

class BatchEmbedResponse(BaseModel):
    embeddings: list[list[float]]
    model: str
    dimensions: int
    total_tokens_used: int
    latency_ms: float
    count: int

class HealthResponse(BaseModel):
    status: str
    model: str
    dimensions: int
    openai_reachable: bool

# ─── Lifespan / Startup ───────────────────────────────────────────────────────

openai_client: AsyncOpenAI | None = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global openai_client
    if not OPENAI_API_KEY:
        logger.error("OPENAI_API_KEY is not set — embedding requests will fail")
    openai_client = AsyncOpenAI(
        api_key=OPENAI_API_KEY,
        timeout=httpx.Timeout(30.0, connect=5.0),
        max_retries=3,
    )
    logger.info("cb-embedder started | model=%s dims=%d", EMBEDDING_MODEL, EMBEDDING_DIMENSIONS)
    yield
    if openai_client:
        await openai_client.close()
    logger.info("cb-embedder shutdown complete")

# ─── App ─────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="cb-python-embedder",
    description="Compliance Buddy — text embedding microservice",
    version="1.0.0",
    lifespan=lifespan,
)

# ─── Middleware: request logging ──────────────────────────────────────────────

@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    duration = (time.perf_counter() - start) * 1000
    logger.info("%s %s -> %d (%.1fms)",
                request.method, request.url.path, response.status_code, duration)
    return response

# ─── Routes ──────────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    """Kubernetes liveness + readiness probe."""
    reachable = False
    try:
        if openai_client:
            # Lightweight call to verify API key + network
            await openai_client.models.retrieve(EMBEDDING_MODEL)
            reachable = True
    except Exception as e:
        logger.warning("OpenAI health check failed: %s", e)

    return HealthResponse(
        status="UP" if reachable else "DEGRADED",
        model=EMBEDDING_MODEL,
        dimensions=EMBEDDING_DIMENSIONS,
        openai_reachable=reachable,
    )

@app.get("/metrics")
async def metrics() -> Response:
    """Prometheus scrape endpoint."""
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.post("/embed", response_model=EmbedResponse)
async def embed_single(req: EmbedRequest) -> EmbedResponse:
    """
    Embed a single text string.
    Returns a list[float] of length req.dimensions.
    """
    start = time.perf_counter()
    try:
        result = await openai_client.embeddings.create(
            input=[req.text],
            model=req.model,
            dimensions=req.dimensions,
        )
        latency = (time.perf_counter() - start) * 1000
        tokens  = result.usage.total_tokens

        embed_requests.labels(status="success").inc()
        embed_tokens.inc(tokens)
        embed_duration.observe(latency / 1000)

        return EmbedResponse(
            embedding=result.data[0].embedding,
            model=result.model,
            dimensions=req.dimensions,
            tokens_used=tokens,
            latency_ms=round(latency, 2),
        )

    except Exception as e:
        embed_requests.labels(status="failure").inc()
        openai_errors.labels(error_type=type(e).__name__).inc()
        logger.exception("Embedding failed")
        raise HTTPException(status_code=502, detail=f"OpenAI error: {e}") from e

@app.post("/embed/batch", response_model=BatchEmbedResponse)
async def embed_batch(req: BatchEmbedRequest) -> BatchEmbedResponse:
    """
    Embed up to MAX_BATCH_SIZE texts in a single OpenAI API call.
    Significantly more efficient than multiple /embed calls.
    """
    if len(req.texts) > MAX_BATCH_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"Batch size {len(req.texts)} exceeds max {MAX_BATCH_SIZE}"
        )

    start = time.perf_counter()
    batch_size_gauge.set(len(req.texts))

    try:
        result = await openai_client.embeddings.create(
            input=req.texts,
            model=req.model,
            dimensions=req.dimensions,
        )
        latency     = (time.perf_counter() - start) * 1000
        total_tokens = result.usage.total_tokens

        # OpenAI returns embeddings in the same order as input
        embeddings = [item.embedding for item in sorted(result.data, key=lambda x: x.index)]

        embed_requests.labels(status="success").inc(len(req.texts))
        embed_tokens.inc(total_tokens)
        embed_duration.observe(latency / 1000)

        return BatchEmbedResponse(
            embeddings=embeddings,
            model=result.model,
            dimensions=req.dimensions,
            total_tokens_used=total_tokens,
            latency_ms=round(latency, 2),
            count=len(embeddings),
        )

    except Exception as e:
        embed_requests.labels(status="failure").inc(len(req.texts))
        openai_errors.labels(error_type=type(e).__name__).inc()
        logger.exception("Batch embedding failed")
        raise HTTPException(status_code=502, detail=f"OpenAI error: {e}") from e

# ─── Global error handler ─────────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.error("Unhandled exception: %s", exc, exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "type": type(exc).__name__},
    )

# ─── Entrypoint ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        workers=4,
        log_level=os.getenv("LOG_LEVEL", "info").lower(),
        access_log=True,
    )
