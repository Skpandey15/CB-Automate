"""
Tests for cb-python-embedder.
Uses unittest.mock to avoid real OpenAI calls.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi.testclient import TestClient

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'app'))


@pytest.fixture
def mock_openai():
    """Provide a mock OpenAI client with a fake embedding response."""
    mock_embedding = MagicMock()
    mock_embedding.embedding = [0.1] * 3072
    mock_embedding.index = 0

    mock_usage = MagicMock()
    mock_usage.total_tokens = 42

    mock_result = MagicMock()
    mock_result.data = [mock_embedding]
    mock_result.usage = mock_usage
    mock_result.model = "text-embedding-3-large"

    mock_client = AsyncMock()
    mock_client.embeddings.create = AsyncMock(return_value=mock_result)
    return mock_client


@pytest.fixture
def client(mock_openai):
    import main as app_module
    app_module.openai_client = mock_openai
    from main import app
    return TestClient(app)


def test_health_endpoint(client):
    resp = client.get("/health")
    # Health may return 200 UP or DEGRADED — both are valid responses
    assert resp.status_code == 200
    data = resp.json()
    assert "status" in data
    assert data["model"] == "text-embedding-3-large"


def test_embed_single_success(client):
    resp = client.post("/embed", json={"text": "SQL injection vulnerability in UserDao"})
    assert resp.status_code == 200
    data = resp.json()
    assert "embedding" in data
    assert len(data["embedding"]) == 3072
    assert data["tokens_used"] == 42
    assert data["latency_ms"] >= 0


def test_embed_empty_text_rejected(client):
    resp = client.post("/embed", json={"text": ""})
    assert resp.status_code == 422


def test_batch_embed_success(client, mock_openai):
    # Setup batch mock
    mock_e0 = MagicMock(); mock_e0.embedding = [0.1] * 3072; mock_e0.index = 0
    mock_e1 = MagicMock(); mock_e1.embedding = [0.2] * 3072; mock_e1.index = 1
    mock_result = MagicMock()
    mock_result.data = [mock_e0, mock_e1]
    mock_result.usage.total_tokens = 80
    mock_result.model = "text-embedding-3-large"
    mock_openai.embeddings.create = AsyncMock(return_value=mock_result)

    resp = client.post("/embed/batch", json={
        "texts": ["vulnerability one", "vulnerability two"]
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["count"] == 2
    assert len(data["embeddings"]) == 2
    assert data["total_tokens_used"] == 80


def test_batch_exceeds_max_size_rejected(client):
    texts = ["text"] * 101
    resp = client.post("/embed/batch", json={"texts": texts})
    assert resp.status_code == 400
    assert "exceeds max" in resp.json()["detail"]


def test_metrics_endpoint(client):
    # First make a request to populate metrics
    client.post("/embed", json={"text": "test"})
    resp = client.get("/metrics")
    assert resp.status_code == 200
    assert b"cb_embed_requests_total" in resp.content
