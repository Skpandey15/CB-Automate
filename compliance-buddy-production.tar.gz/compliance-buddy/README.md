# Compliance Buddy (CB)

> AI-powered autonomous security remediation agent for Java/Spring Boot microservices.

---

## Architecture overview

```
SonarQube webhook
      │
      ▼
cb-scanner-adapter   ──Kafka──▶  cb-ai-agent  ──▶  cb-pr-service
(maps to cb: ontology)           (RAG + LLM)         (GitHub PR)
      │                               │                    │
      └──────────────────────────────▼────────────────────▼
                              cb-audit-service        cb-notification-service
                              (immutable log)         (Slack + Datadog)
                                    │
                              cb-python-embedder
                              (text-embedding-3-large)
                                    │
                              MongoDB Atlas
                              (vector store)
```

### Services

| Service | Port | Language | Responsibility |
|---------|------|----------|----------------|
| `cb-scanner-adapter` | 8083 | Java 21 / Spring Boot | SonarQube webhook consumer, OntologyMapper |
| `cb-ontology-service` | 8081 | Java 21 / Spring Boot | cb: domain model, MongoDB CRUD, REST API |
| `cb-ai-agent` | 8082 | Java 21 / Spring Boot | RAG retrieval + LLM inference + fix generation |
| `cb-pr-service` | 8084 | Java 21 / Spring Boot | GitHub Enterprise PR creation |
| `cb-notification-service` | 8085 | Java 21 / Spring Boot | Slack + Datadog notifications |
| `cb-audit-service` | 8086 | Java 21 / Spring Boot | Immutable audit log, Kafka consumer |
| `cb-gateway` | 8080 | Java 21 / Spring Cloud Gateway | API gateway, auth, rate limiting |
| `cb-python-embedder` | 8000 | Python 3.12 / FastAPI | text-embedding-3-large via OpenAI |

---

## Quick start — local k3d

### Prerequisites

```bash
brew install k3d kubectl helm docker
# Set environment variables
export OPENAI_API_KEY=sk-...
export ANTHROPIC_API_KEY=sk-ant-...
export GITHUB_TOKEN=ghp-...
export DATADOG_API_KEY=dd-...
```

### Bootstrap

```bash
git clone https://github.allstate.com/java-platform/compliance-buddy
cd compliance-buddy
chmod +x scripts/bootstrap-k3d.sh
./scripts/bootstrap-k3d.sh
```

This will:
1. Create a local k3d cluster with 2 agent nodes
2. Start a local image registry on port 5050
3. Install Kafka + MongoDB via Helm
4. Build all Docker images and push to local registry
5. Apply all Kubernetes manifests
6. Print access URLs

### Access

- Gateway: `http://localhost:8080/api/`
- Swagger: `http://localhost:8080/api/swagger-ui.html`
- Embedder: `http://localhost:8000/docs`

---

## cb: Ontology Namespace

Base IRI: `https://techseva.in/ontology/compliance-buddy#`

| Prefix | IRI |
|--------|-----|
| `cb:` | `https://techseva.in/ontology/compliance-buddy#` |
| `owl:` | `http://www.w3.org/2002/07/owl#` |
| `rdfs:` | `http://www.w3.org/2000/01/rdf-schema#` |

### Classes

- `cb:SecurityFinding` — root class
  - `cb:Vulnerability` — SonarQube security issue
  - `cb:CodeSmell` — maintainability issue
  - `cb:PolicyViolation` — regulatory breach
- `cb:Fix` — LLM-generated patch
- `cb:CodeArtifact` — affected source file
- `cb:Review` — human/bot review decision
- `cb:Notification` — team alert
- `cb:AuditEvent` — immutable log entry

### Object properties

| Property | Domain | Range |
|----------|--------|-------|
| `cb:remediatedBy` | `cb:Vulnerability` | `cb:Fix` |
| `cb:affects` | `cb:Vulnerability` | `cb:CodeArtifact` |
| `cb:hasVuln` | `cb:CodeArtifact` | `cb:Vulnerability` |
| `cb:validatedBy` | `cb:Fix` | `cb:Review` |
| `cb:triggers` | `cb:Fix` | `cb:Notification` |

---

## Development

### Build all services

```bash
./gradlew build --parallel
```

### Run a single service

```bash
./gradlew :cb-ai-agent:bootRun
```

### Python embedder

```bash
cd cb-python-embedder
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
pytest tests/ -v
```

### Run integration tests

```bash
./gradlew test --tests "*.integration.*"
```

---

## Resilience4j configuration

All circuit breakers and retry policies are configured in each service's `application.yml`.

| Component | Circuit breaker | Retry | Timeout |
|-----------|----------------|-------|---------|
| LLM inference | 50% threshold, 30s wait | 3× 5s exponential | 45s |
| GitHub API | 40% threshold, 60s wait | 3× 2s | 30s |
| MongoDB | 60% threshold, 15s wait | 2× 1s | 10s |
| Embedder | 50% threshold, 20s wait | 2× 3s | 15s |

---

## Kafka topics

| Topic | Producer | Consumer | Schema |
|-------|----------|----------|--------|
| `sonarqube.webhook.events` | SonarQube | cb-scanner-adapter | Raw SQ JSON |
| `cb.vulnerability.detected` | cb-scanner-adapter | cb-ai-agent | cb:Vulnerability JSON-LD |
| `cb.fix.generated` | cb-ai-agent | cb-pr-service, cb-notification-service | cb:Fix JSON-LD |
| `cb.audit.events` | All services | cb-audit-service | cb:AuditEvent JSON-LD |
| `cb.notification.send` | cb-pr-service | cb-notification-service | cb:Notification JSON-LD |

---

## Datadog metrics

| Metric | Type | Tags |
|--------|------|------|
| `cb.vulnerability.detected` | Counter | cweId, severity, projectKey |
| `cb.fix.generated` | Counter | cweId, severity, strategy |
| `cb.fix.confidence` | Gauge | cweId |
| `cb.fix.failed` | Counter | cweId, severity, reason |
| `cb.pr.raised` | Counter | cweId, severity |
| `cb.llm.inference.duration` | Histogram | cweId, model |
| `cb.rag.retrieval` | Counter | cweId, results |
| `cb.vuln.mttr` | Gauge | cweId, projectKey |

---

## Security

- All secrets stored in HashiCorp Vault (k8s: injected as env via Kubernetes Secrets — replace with Vault agent injector in production)
- Non-root containers (`runAsUser: 1001`)
- NetworkPolicy restricting inter-pod communication to `cb-system` namespace
- LLM output validated as JSON-LD before any GitHub API call
- MongoDB field-level encryption for `cb:patchDiff` and `cb:prUrl`

---

*Compliance Buddy v1.0 — Allstate India Java Platform Engineering — TechSeva*
