package in.techseva.cb.pr.service;

import in.techseva.cb.ontology.model.CbAuditEvent;
import in.techseva.cb.ontology.model.CbFix;
import in.techseva.cb.ontology.model.CbVulnerability;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;

/**
 * PRCreationService
 *
 * Creates a GitHub Enterprise pull request from a cb:Fix patch diff.
 *
 * Workflow:
 *   1. Fetch current file content + SHA from GHE API
 *   2. Apply unified diff to produce new file content
 *   3. Create branch: cb/fix/{cweId}-{shortId}
 *   4. Commit patched file to the new branch
 *   5. Open PR with JSON-LD body for full traceability
 *   6. Return prUrl → stored back on cb:Fix
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PRCreationService {

    private final RestClient   gheClient;
    private final PatchApplier patchApplier;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final MeterRegistry meterRegistry;

    @Value("${cb.github.default-branch:main}")
    private String defaultBranch;

    @Value("${cb.github.owner}")
    private String repoOwner;

    @Value("${cb.github.repo}")
    private String repoName;

    private static final String AUDIT_TOPIC = "cb.audit.events";

    /**
     * Create a pull request for the given fix.
     *
     * @return updated CbFix with prUrl and branchName set, status=PR_RAISED
     */
    @CircuitBreaker(name = "github-api", fallbackMethod = "prFallback")
    public CbFix createPullRequest(CbFix fix, CbVulnerability vulnerability, String correlationId) {
        String filePath   = vulnerability.affects().filePath();
        String branchName = buildBranchName(vulnerability.cweId(), fix.id());

        log.info("[PRCreation] Creating PR for fix={} branch={}", fix.id(), branchName);

        try {
            // 1. Get default branch SHA
            String baseSha = getDefaultBranchSha();

            // 2. Get current file content
            FileContent current = getFileContent(filePath);

            // 3. Apply patch
            String patchedContent = patchApplier.apply(current.content(), fix.patchDiff());

            // 4. Create branch from default
            createBranch(branchName, baseSha);

            // 5. Commit patched file
            String commitSha = commitFile(filePath, patchedContent, current.sha(),
                branchName, buildCommitMessage(vulnerability));

            // 6. Open PR
            String prUrl = openPullRequest(branchName, fix, vulnerability, correlationId);

            log.info("[PRCreation] PR created: {}", prUrl);

            meterRegistry.counter("cb.pr.raised",
                "cweId", vulnerability.cweId(),
                "severity", vulnerability.severity()
            ).increment();

            publishAudit(CbAuditEvent.Action.PR_RAISED, fix.id(),
                "SUCCESS", correlationId, Map.of("prUrl", prUrl, "branch", branchName));

            return fix.toBuilder()
                .prUrl(prUrl)
                .branchName(branchName)
                .status("PR_RAISED")
                .build();

        } catch (Exception e) {
            log.error("[PRCreation] Failed to create PR for fix={}: {}", fix.id(), e.getMessage(), e);
            publishAudit(CbAuditEvent.Action.PR_FAILED, fix.id(),
                "FAILURE", correlationId, Map.of("error", e.getMessage()));
            throw e;
        }
    }

    @SuppressWarnings("unused")
    public CbFix prFallback(CbFix fix, CbVulnerability vulnerability,
                             String correlationId, Throwable ex) {
        log.error("[PRCreation] Circuit OPEN for GitHub API: {}", ex.getMessage());
        meterRegistry.counter("cb.pr.failed",
            "cweId", vulnerability.cweId(), "reason", "circuit_open").increment();
        return fix.toBuilder().status("FAILED")
            .rejectionReason("GitHub API unavailable: " + ex.getMessage()).build();
    }

    // ─── GitHub API helpers ──────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private String getDefaultBranchSha() {
        Map<String, Object> ref = gheClient.get()
            .uri("/repos/{owner}/{repo}/git/ref/heads/{branch}",
                repoOwner, repoName, defaultBranch)
            .retrieve()
            .body(Map.class);
        return (String) ((Map<String, Object>)
            ((Map<String, Object>) ref.get("object"))).get("sha");
    }

    @SuppressWarnings("unchecked")
    private FileContent getFileContent(String filePath) {
        Map<String, Object> resp = gheClient.get()
            .uri("/repos/{owner}/{repo}/contents/{path}",
                repoOwner, repoName, filePath)
            .retrieve()
            .body(Map.class);
        String encoded = (String) resp.get("content");
        String sha     = (String) resp.get("sha");
        // GitHub returns base64 content with newlines
        byte[] decoded = Base64.getMimeDecoder().decode(encoded);
        return new FileContent(new String(decoded), sha);
    }

    private void createBranch(String branchName, String baseSha) {
        gheClient.post()
            .uri("/repos/{owner}/{repo}/git/refs", repoOwner, repoName)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Map.of(
                "ref", "refs/heads/" + branchName,
                "sha", baseSha
            ))
            .retrieve()
            .toBodilessEntity();
    }

    @SuppressWarnings("unchecked")
    private String commitFile(String filePath, String content, String currentSha,
                               String branchName, String message) {
        String encoded = Base64.getEncoder().encodeToString(content.getBytes());
        Map<String, Object> resp = gheClient.put()
            .uri("/repos/{owner}/{repo}/contents/{path}", repoOwner, repoName, filePath)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Map.of(
                "message", message,
                "content", encoded,
                "sha", currentSha,
                "branch", branchName
            ))
            .retrieve()
            .body(Map.class);
        return (String) ((Map<String, Object>)
            ((Map<String, Object>) resp.get("commit"))).get("sha");
    }

    @SuppressWarnings("unchecked")
    private String openPullRequest(String branchName, CbFix fix,
                                    CbVulnerability vuln, String correlationId) {
        String title = "[CB] Fix %s in %s (confidence: %.0f%%)".formatted(
            vuln.cweId(),
            vuln.affects().filePath(),
            fix.confidence() * 100
        );
        String body = buildPrBody(fix, vuln, correlationId);

        Map<String, Object> pr = gheClient.post()
            .uri("/repos/{owner}/{repo}/pulls", repoOwner, repoName)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Map.of(
                "title", title,
                "head",  branchName,
                "base",  defaultBranch,
                "body",  body,
                "draft", false
            ))
            .retrieve()
            .body(Map.class);

        return (String) pr.get("html_url");
    }

    private String buildPrBody(CbFix fix, CbVulnerability vuln, String correlationId) {
        return """
            ## Compliance Buddy — Automated Security Fix

            | Field | Value |
            |-------|-------|
            | **CWE** | %s |
            | **Severity** | %s |
            | **OWASP** | %s |
            | **Rule** | %s |
            | **File** | `%s` Line %d |
            | **Strategy** | %s |
            | **LLM Confidence** | %.0f%% |
            | **Model** | %s |
            | **Correlation ID** | `%s` |

            ### Remediation strategy
            %s

            <details>
            <summary>cb:Fix JSON-LD (machine-readable traceability)</summary>

            ```json
            {
              "@type": "cb:Fix",
              "@id": "%s",
              "cb:remediates": "%s",
              "cb:strategy": "%s",
              "cb:confidence": %s,
              "cb:llmModel": "%s"
            }
            ```
            </details>

            ---
            *Generated by [Compliance Buddy](https://techseva.in/cb) · %s*
            """.formatted(
                vuln.cweId(), vuln.severity(), vuln.owaspCategory(),
                vuln.ruleKey(), vuln.affects().filePath(), vuln.lineNo(),
                fix.strategy(), fix.confidence() * 100, fix.llmModel(),
                correlationId,
                describeStrategy(fix.strategy()),
                fix.id(), fix.vulnId(), fix.strategy(), fix.confidence(), fix.llmModel(),
                Instant.now()
            );
    }

    private String describeStrategy(String strategy) {
        return switch (strategy) {
            case "PreparedStatement"   -> "Replaced string-concatenated SQL with `PreparedStatement` parameterized queries to prevent SQL injection.";
            case "OutputEncoding"      -> "Applied `HtmlUtils.htmlEscape()` to user-controlled output to prevent XSS.";
            case "VaultSecret"         -> "Replaced hard-coded credential with `@Value` backed by HashiCorp Vault.";
            case "SecureRandom"        -> "Replaced `Math.random()` / weak RNG with `SecureRandom` for cryptographic operations.";
            default                    -> "Applied automated remediation via Compliance Buddy AI agent.";
        };
    }

    private String buildBranchName(String cweId, String fixId) {
        String shortId = fixId.replaceAll("[^a-zA-Z0-9-]", "").substring(0, Math.min(20, fixId.length()));
        return "cb/fix/%s-%s".formatted(cweId.toLowerCase(), shortId);
    }

    private String buildCommitMessage(CbVulnerability vuln) {
        return "fix(%s): remediate %s in %s [CB-AUTO]".formatted(
            vuln.cweId().toLowerCase(),
            vuln.ruleKey(),
            vuln.affects().filePath()
        );
    }

    private void publishAudit(CbAuditEvent.Action action, String targetId,
                               String outcome, String correlationId, Map<String, Object> details) {
        CbAuditEvent event = CbAuditEvent.builder()
            .id("cb:audit-" + UUID.randomUUID())
            .actor("cb-pr-service")
            .action(action.name())
            .targetId(targetId)
            .targetType("cb:Fix")
            .outcome(outcome)
            .details(details)
            .correlationId(correlationId)
            .timestamp(Instant.now())
            .build();
        kafkaTemplate.send(AUDIT_TOPIC, event.id(), event);
    }

    record FileContent(String content, String sha) {}
}
