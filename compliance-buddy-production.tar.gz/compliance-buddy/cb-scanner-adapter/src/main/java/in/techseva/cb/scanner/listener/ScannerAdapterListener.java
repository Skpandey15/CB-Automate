package in.techseva.cb.scanner.listener;

import in.techseva.cb.ontology.mapper.OntologyMapper;
import in.techseva.cb.ontology.model.CbAuditEvent;
import in.techseva.cb.ontology.model.CbVulnerability;
import in.techseva.cb.ontology.repository.VulnerabilityRepository;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * ScannerAdapterListener
 *
 * Consumes SonarQube webhook payloads from topic: sonarqube.webhook.events
 * Maps each issue to cb:Vulnerability via OntologyMapper
 * Publishes actionable findings to: cb.vulnerability.detected
 *
 * Idempotency: checks MongoDB before processing to skip duplicates.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ScannerAdapterListener {

    private final OntologyMapper           ontologyMapper;
    private final VulnerabilityRepository  vulnerabilityRepository;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final MeterRegistry            meterRegistry;

    @Value("${cb.github.repo-url:https://github.allstate.com}")
    private String repoBaseUrl;

    private static final String VULN_TOPIC  = "cb.vulnerability.detected";
    private static final String AUDIT_TOPIC = "cb.audit.events";

    @KafkaListener(
        topics = "sonarqube.webhook.events",
        groupId = "cb-scanner-adapter",
        concurrency = "3"
    )
    @SuppressWarnings("unchecked")
    public void onSonarQubeEvent(ConsumerRecord<String, Map<String, Object>> record,
                                  Acknowledgment ack) {
        String correlationId = UUID.randomUUID().toString();
        MDC.put("correlationId", correlationId);

        try {
            Map<String, Object> payload = record.value();
            String projectKey = (String) payload.getOrDefault("project", Map.of())
                .toString();

            // SonarQube sends a "taskId" we use as idempotency key
            String taskId = (String) payload.get("taskId");

            log.info("[Scanner] Received SonarQube event taskId={} correlationId={}",
                taskId, correlationId);

            Object issuesObj = payload.get("issues");
            if (!(issuesObj instanceof java.util.List<?> issues)) {
                log.warn("[Scanner] No issues in payload for taskId={}", taskId);
                ack.acknowledge();
                return;
            }

            int processed = 0;
            int skipped   = 0;

            for (Object issueObj : issues) {
                if (!(issueObj instanceof Map<?, ?> rawIssue)) continue;
                Map<String, Object> issue = (Map<String, Object>) rawIssue;

                try {
                    // Map to cb:Vulnerability
                    CbVulnerability vuln = ontologyMapper.mapIssue(
                        issue,
                        repoBaseUrl + "/" + projectKey,
                        projectKey
                    );

                    // Idempotency check
                    if (vulnerabilityRepository.existsById(vuln.id())) {
                        log.debug("[Scanner] Duplicate finding skipped: {}", vuln.id());
                        skipped++;
                        continue;
                    }

                    // Persist
                    vulnerabilityRepository.save(vuln);

                    // Publish actionable findings only
                    if (vuln.isActionable()) {
                        kafkaTemplate.send(VULN_TOPIC, vuln.id(), vuln);
                        log.info("[Scanner] Published actionable finding: {} cwe={}",
                            vuln.id(), vuln.cweId());
                    }

                    // Audit
                    publishAudit(CbAuditEvent.Action.VULNERABILITY_DETECTED,
                        vuln.id(), "SUCCESS", correlationId,
                        Map.of("cweId", vuln.cweId(), "severity", vuln.severity()));

                    meterRegistry.counter("cb.vulnerability.detected",
                        "cweId", vuln.cweId(),
                        "severity", vuln.severity(),
                        "projectKey", projectKey
                    ).increment();

                    processed++;

                } catch (Exception e) {
                    log.error("[Scanner] Failed to process issue: {}", e.getMessage(), e);
                    meterRegistry.counter("cb.vulnerability.processing.error").increment();
                }
            }

            log.info("[Scanner] taskId={} processed={} skipped={}", taskId, processed, skipped);
            ack.acknowledge();

        } finally {
            MDC.clear();
        }
    }

    private void publishAudit(CbAuditEvent.Action action, String targetId,
                               String outcome, String correlationId,
                               Map<String, Object> details) {
        CbAuditEvent event = CbAuditEvent.builder()
            .id("cb:audit-" + UUID.randomUUID())
            .actor("cb-scanner-adapter")
            .action(action.name())
            .targetId(targetId)
            .targetType("cb:Vulnerability")
            .outcome(outcome)
            .details(details)
            .correlationId(correlationId)
            .timestamp(Instant.now())
            .build();
        kafkaTemplate.send(AUDIT_TOPIC, event.id(), event);
    }
}
