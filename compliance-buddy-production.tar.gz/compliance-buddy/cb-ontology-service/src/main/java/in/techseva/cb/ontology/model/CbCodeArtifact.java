package in.techseva.cb.ontology.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

/**
 * cb:CodeArtifact — the source file that contains the vulnerability.
 * Embedded inside CbVulnerability (cb:affects) and stored as top-level
 * collection for artifact-centric queries via cb:hasVuln.
 */
@Builder(toBuilder = true)
public record CbCodeArtifact(

    @JsonProperty("@id")
    String id,                          // cb:artifact-{safeFilePath}

    @JsonProperty("@type")
    @Builder.Default
    String type = "cb:CodeArtifact",

    @NotBlank
    @JsonProperty("cb:filePath")
    String filePath,                    // repo-relative path

    @JsonProperty("cb:language")
    @Builder.Default
    String language = "Java",

    @JsonProperty("cb:framework")
    String framework,                   // e.g. Spring Boot 4

    @JsonProperty("cb:buildTool")
    @Builder.Default
    String buildTool = "Gradle Groovy DSL",

    @JsonProperty("cb:packageName")
    String packageName,

    @JsonProperty("cb:version")
    String version,

    @JsonProperty("cb:repoUrl")
    String repoUrl

) {
    public static String buildId(String filePath) {
        return "cb:artifact-" + filePath.replaceAll("[^a-zA-Z0-9]", "-");
    }
}
