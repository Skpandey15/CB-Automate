package in.techseva.cb.ontology.repository;

import in.techseva.cb.ontology.model.CbFix;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * VectorSearchRepository
 *
 * Executes MongoDB Atlas $vectorSearch aggregation to find the top-k
 * cb:Fix instances semantically similar to a given query embedding.
 *
 * Index name: cb_fix_vector_index
 * Index definition (Atlas UI / CLI):
 * {
 *   "fields": [{
 *     "type": "vector",
 *     "path": "cb:embeddingVector",
 *     "numDimensions": 3072,
 *     "similarity": "cosine"
 *   }]
 * }
 */
@Slf4j
@Repository
@RequiredArgsConstructor
public class VectorSearchRepository {

    private final MongoTemplate mongoTemplate;

    private static final String FIX_COLLECTION    = "cb_fixes";
    private static final String VECTOR_INDEX_NAME = "cb_fix_vector_index";
    private static final String VECTOR_PATH       = "cb:embeddingVector";

    /**
     * Find top-k cb:Fix instances by cosine similarity to queryVector.
     *
     * @param queryVector  3072-dim float[] from EmbeddingService
     * @param topK         number of results (default 5)
     * @param minScore     minimum similarity score threshold (0.0–1.0)
     * @return list of similar CbFix records, ordered by descending score
     */
    public List<CbFix> findSimilarFixes(float[] queryVector, int topK, double minScore) {
        log.debug("[VectorSearch] Querying {} with topK={} minScore={}", FIX_COLLECTION, topK, minScore);

        // Build the $vectorSearch stage as a raw BSON document
        // (Spring Data MongoDB does not yet have a typed VectorSearch operation)
        Document vectorSearchStage = new Document("$vectorSearch", new Document()
            .append("index", VECTOR_INDEX_NAME)
            .append("path", VECTOR_PATH)
            .append("queryVector", toDoubleList(queryVector))
            .append("numCandidates", topK * 10)  // oversampling for accuracy
            .append("limit", topK)
        );

        // Filter by minimum score using $match on vectorSearchScore
        Document addFieldsStage = new Document("$addFields", new Document()
            .append("score", new Document("$meta", "vectorSearchScore"))
        );

        Document matchStage = new Document("$match", new Document()
            .append("score", new Document("$gte", minScore))
        );

        AggregationOperation rawVectorSearch = ctx -> vectorSearchStage;
        AggregationOperation addScore       = ctx -> addFieldsStage;
        AggregationOperation filterScore    = ctx -> matchStage;

        Aggregation aggregation = Aggregation.newAggregation(
            rawVectorSearch,
            addScore,
            filterScore
        );

        List<CbFix> results = mongoTemplate.aggregate(
            aggregation, FIX_COLLECTION, CbFix.class
        ).getMappedResults();

        log.info("[VectorSearch] Retrieved {} similar fixes (topK={}, minScore={})",
            results.size(), topK, minScore);

        return results;
    }

    private List<Double> toDoubleList(float[] floats) {
        List<Double> list = new java.util.ArrayList<>(floats.length);
        for (float f : floats) list.add((double) f);
        return list;
    }
}
