package in.techseva.cb.ontology.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import lombok.Builder;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;

/**
 * cb:Fix — an LLM-generated remediation patch.
 *
 * Lifecycle: GENERATED → PR_RAISED → REVIEW_PENDING → APPROVED | REJECTED
 *
 * MongoDB collection: cb_fixes
 * Kafka topic: cb.fix.generated
 */
@Document(collection = "cb_fixes")
@Builder(toBuilder = true)
public record CbFix(

    @Id
    @JsonProperty("@id")
    String id,                          // cb:fix-{cweId}-{shortVulnId}-v{n}

    @JsonProperty("@type")
    @Builder.Default
    String type = "cb:Fix",

    @NotBlank
    @JsonProperty("cb:remediates")
    String vulnId,                      // IRI of the parent cb:Vulnerability

    @NotBlank
    @JsonProperty("cb:patchDiff")
    String patchDiff,                   // unified diff string

    @NotBlank
    @JsonProperty("cb:strategy")
    String strategy,                    // e.g. PreparedStatement, ParameterizedQuery

    @DecimalMin("0.0") @DecimalMax("1.0")
    @JsonProperty("cb:confidence")
    double confidence,

    @NotBlank
    @JsonProperty("cb:llmModel")
    String llmModel,                    // e.g. gpt-4o, claude-sonnet-4-6

    @JsonProperty("cb:priorFixIds")
    List<String> priorFixIds,           // RAG context — IRIs of retrieved cb:Fix

    @JsonProperty("cb:prUrl")
    String prUrl,

    @JsonProperty("cb:branchName")
    String branchName,

    @Pattern(regexp = "GENERATED|PR_RAISED|REVIEW_PENDING|APPROVED|REJECTED|FAILED")
    @JsonProperty("cb:status")
    String status,

    @JsonProperty("cb:rejectionReason")
    String rejectionReason,

    @JsonProperty("cb:tokensUsed")
    int tokensUsed,

    @CreatedDate
    @JsonProperty("cb:generatedAt")
    Instant generatedAt,

    @JsonProperty("cb:resolvedAt")
    Instant resolvedAt

) {
    public static String buildId(String cweId, String vulnId, int version) {
        String shortId = vulnId.replaceAll("[^a-zA-Z0-9]", "-").substring(0, Math.min(20, vulnId.length()));
        return "cb:fix-%s-%s-v%d".formatted(cweId.toLowerCase(), shortId, version);
    }
}
