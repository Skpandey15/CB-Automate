package in.techseva.cb.ontology.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.Map;

/**
 * cb:AuditEvent — immutable event log entry.
 *
 * Every state transition in CB produces an AuditEvent.
 * TTL index of 90 days applied in MongoConfig.
 * Also published to Kafka topic cb.audit.events as JSON-LD.
 */
@Document(collection = "cb_audit_events")
@Builder
public record CbAuditEvent(

    @Id
    @JsonProperty("@id")
    String id,

    @JsonProperty("@type")
    @Builder.Default
    String type = "cb:AuditEvent",

    @Indexed
    @JsonProperty("cb:actor")
    String actor,                       // service name e.g. cb-ai-agent

    @JsonProperty("cb:action")
    String action,                      // e.g. VULNERABILITY_DETECTED, FIX_GENERATED

    @Indexed
    @JsonProperty("cb:target")
    String targetId,                    // IRI of the affected entity

    @JsonProperty("cb:targetType")
    String targetType,                  // e.g. cb:Vulnerability

    @JsonProperty("cb:outcome")
    String outcome,                     // SUCCESS | FAILURE

    @JsonProperty("cb:details")
    Map<String, Object> details,        // arbitrary context bag

    @JsonProperty("cb:correlationId")
    String correlationId,               // trace ID for distributed tracing

    @Indexed(expireAfterSeconds = 7_776_000) // 90 days TTL
    @JsonProperty("cb:timestamp")
    Instant timestamp

) {
    public enum Action {
        VULNERABILITY_DETECTED,
        ONTOLOGY_MAPPED,
        EMBEDDING_GENERATED,
        RAG_RETRIEVED,
        LLM_INVOKED,
        FIX_GENERATED,
        PR_RAISED,
        PR_FAILED,
        NOTIFICATION_SENT,
        REVIEW_APPROVED,
        REVIEW_REJECTED,
        RETRY_TRIGGERED,
        CIRCUIT_OPENED
    }
}
