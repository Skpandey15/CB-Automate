package in.techseva.cb.ontology.mapper;

import in.techseva.cb.ontology.model.CbCodeArtifact;
import in.techseva.cb.ontology.model.CbVulnerability;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * OntologyMapper
 *
 * Converts raw SonarQube Issue payload (Map<String, Object>) into
 * fully typed cb:Vulnerability + cb:CodeArtifact graph.
 *
 * Mapping rules are documented in LLD §4.1.
 */
@Slf4j
@Component
public class OntologyMapper {

    private static final Pattern CWE_PATTERN    = Pattern.compile("cwe:(CWE-\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern OWASP_PATTERN  = Pattern.compile("(A\\d{2}:\\d{4})", Pattern.CASE_INSENSITIVE);

    private static final Map<String, String> TAG_TO_FRAMEWORK = Map.of(
        "spring",    "Spring Boot 4",
        "servlet",   "Spring Boot 4",
        "jpa",       "Spring Data JPA",
        "kafka",     "Apache Kafka 3.x",
        "jdbc",      "JDBC / Spring JDBC"
    );

    private static final Map<String, String> SEVERITY_MAP = Map.of(
        "BLOCKER",  "BLOCKER",
        "CRITICAL", "CRITICAL",
        "MAJOR",    "MAJOR",
        "MINOR",    "MINOR",
        "INFO",     "INFO"
    );

    /**
     * Map a SonarQube issue payload to a CbVulnerability.
     *
     * @param issue raw SonarQube JSON as Map
     * @param repoUrl GitHub Enterprise repo URL
     * @param projectKey SonarQube project key
     * @return populated CbVulnerability ready for persistence
     */
    @SuppressWarnings("unchecked")
    public CbVulnerability mapIssue(Map<String, Object> issue, String repoUrl, String projectKey) {
        String component   = (String) issue.getOrDefault("component", "unknown");
        String filePath    = extractFilePath(component, projectKey);
        int    lineNo      = extractLineNo(issue);
        String cweId       = extractCwe(issue);
        String severity    = normalizeSeverity((String) issue.getOrDefault("severity", "MAJOR"));
        String ruleKey     = (String) issue.getOrDefault("rule", "unknown");
        String effort      = parseDuration((String) issue.get("effort"));
        String message     = (String) issue.getOrDefault("message", "");
        String owaspCat    = extractOwasp(issue);
        String framework   = extractFramework(issue);
        String lang        = detectLanguage(filePath);

        CbCodeArtifact artifact = CbCodeArtifact.builder()
            .id(CbCodeArtifact.buildId(filePath))
            .filePath(filePath)
            .language(lang)
            .framework(framework)
            .repoUrl(repoUrl)
            .build();

        String vulnId = CbVulnerability.buildId(cweId, filePath, lineNo);

        log.info("[OntologyMapper] Mapped issue {} -> {}", ruleKey, vulnId);

        return CbVulnerability.builder()
            .id(vulnId)
            .cweId(cweId)
            .severity(severity)
            .ruleKey(ruleKey)
            .lineNo(lineNo)
            .effort(effort)
            .status("OPEN")
            .message(message)
            .owaspCategory(owaspCat)
            .affects(artifact)
            .projectKey(projectKey)
            .detectedAt(Instant.now())
            .updatedAt(Instant.now())
            .build();
    }

    // ─── Private helpers ────────────────────────────────────────────────────

    private String extractFilePath(String component, String projectKey) {
        // SonarQube component format: projectKey:src/main/java/...
        if (component.contains(":")) {
            return component.substring(component.indexOf(':') + 1);
        }
        return component;
    }

    @SuppressWarnings("unchecked")
    private int extractLineNo(Map<String, Object> issue) {
        Object textRange = issue.get("textRange");
        if (textRange instanceof Map<?, ?> tr) {
            Object line = tr.get("startLine");
            if (line instanceof Number n) return n.intValue();
        }
        return 1;
    }

    @SuppressWarnings("unchecked")
    private String extractCwe(Map<String, Object> issue) {
        Object tagsObj = issue.get("tags");
        if (tagsObj instanceof java.util.List<?> tags) {
            for (Object tag : tags) {
                Matcher m = CWE_PATTERN.matcher(tag.toString());
                if (m.find()) return m.group(1).toUpperCase();
            }
        }
        // Fallback: try to infer from ruleKey
        String rule = (String) issue.getOrDefault("rule", "");
        return inferCweFromRule(rule);
    }

    private String inferCweFromRule(String ruleKey) {
        return switch (ruleKey) {
            case "java:S2077", "java:S3649" -> "CWE-89";   // SQL injection
            case "java:S5131"               -> "CWE-79";   // XSS
            case "java:S2076"               -> "CWE-78";   // OS command injection
            case "java:S2083"               -> "CWE-22";   // Path traversal
            case "java:S5144"               -> "CWE-918";  // SSRF
            case "java:S5542"               -> "CWE-327";  // Weak crypto
            case "java:S2115"               -> "CWE-798";  // Hard-coded credential
            default                          -> "CWE-UNKNOWN";
        };
    }

    @SuppressWarnings("unchecked")
    private String extractOwasp(Map<String, Object> issue) {
        Object tagsObj = issue.get("tags");
        if (tagsObj instanceof java.util.List<?> tags) {
            for (Object tag : tags) {
                Matcher m = OWASP_PATTERN.matcher(tag.toString());
                if (m.find()) return m.group(1).toUpperCase();
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private String extractFramework(Map<String, Object> issue) {
        Object tagsObj = issue.get("tags");
        if (tagsObj instanceof java.util.List<?> tags) {
            for (Object tag : tags) {
                String t = tag.toString().toLowerCase();
                if (TAG_TO_FRAMEWORK.containsKey(t)) return TAG_TO_FRAMEWORK.get(t);
            }
        }
        return "Spring Boot 4";
    }

    private String detectLanguage(String filePath) {
        if (filePath.endsWith(".java"))  return "Java";
        if (filePath.endsWith(".kt"))    return "Kotlin";
        if (filePath.endsWith(".py"))    return "Python";
        return "Java";
    }

    private String normalizeSeverity(String raw) {
        return SEVERITY_MAP.getOrDefault(raw.toUpperCase(), "MAJOR");
    }

    /**
     * Convert SonarQube effort string (e.g. "30min", "2h") to ISO 8601 duration.
     */
    private String parseDuration(String effort) {
        if (effort == null || effort.isBlank()) return "PT0S";
        effort = effort.trim().toLowerCase();
        try {
            if (effort.endsWith("min")) {
                int mins = Integer.parseInt(effort.replace("min", "").trim());
                return "PT%dM".formatted(mins);
            }
            if (effort.endsWith("h")) {
                int hrs = Integer.parseInt(effort.replace("h", "").trim());
                return "PT%dH".formatted(hrs);
            }
            if (effort.endsWith("d")) {
                int days = Integer.parseInt(effort.replace("d", "").trim());
                return "P%dD".formatted(days);
            }
        } catch (NumberFormatException e) {
            log.warn("[OntologyMapper] Cannot parse effort '{}', defaulting PT0S", effort);
        }
        return "PT0S";
    }
}
