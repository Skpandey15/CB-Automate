#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Compliance Buddy — k3d Local Cluster Bootstrap
#
# Prerequisites:
#   brew install k3d kubectl helm docker
#   (or equivalent for your OS)
#
# Usage:
#   chmod +x scripts/bootstrap-k3d.sh
#   ./scripts/bootstrap-k3d.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

CLUSTER_NAME="compliance-buddy"
REGISTRY_NAME="cb-registry"
REGISTRY_PORT="5050"
NAMESPACE="cb-system"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
log()  { echo -e "${GREEN}[CB]${NC} $1"; }
warn() { echo -e "${YELLOW}[CB]${NC} $1"; }
err()  { echo -e "${RED}[CB]${NC} $1"; exit 1; }

# ── 1. Preflight checks ──────────────────────────────────────────────────────
command -v k3d     >/dev/null || err "k3d not found. Install: brew install k3d"
command -v kubectl >/dev/null || err "kubectl not found. Install: brew install kubectl"
command -v helm    >/dev/null || err "helm not found. Install: brew install helm"
command -v docker  >/dev/null || err "docker not found."

log "All prerequisites present"

# ── 2. Local image registry ──────────────────────────────────────────────────
if k3d registry list 2>/dev/null | grep -q "$REGISTRY_NAME"; then
    warn "Registry $REGISTRY_NAME already exists — skipping"
else
    log "Creating local image registry: $REGISTRY_NAME:$REGISTRY_PORT"
    k3d registry create "$REGISTRY_NAME" --port "$REGISTRY_PORT"
fi

# ── 3. k3d cluster ───────────────────────────────────────────────────────────
if k3d cluster list 2>/dev/null | grep -q "$CLUSTER_NAME"; then
    warn "Cluster $CLUSTER_NAME already exists — skipping creation"
else
    log "Creating k3d cluster: $CLUSTER_NAME"
    k3d cluster create "$CLUSTER_NAME" \
        --agents 2 \
        --registry-use "k3d-$REGISTRY_NAME:$REGISTRY_PORT" \
        --port "8080:80@loadbalancer" \
        --port "8443:443@loadbalancer" \
        --k3s-arg "--disable=traefik@server:0" \
        --wait
fi

kubectl config use-context "k3d-$CLUSTER_NAME"
log "Switched kubectl context to k3d-$CLUSTER_NAME"

# ── 4. Namespace + RBAC ──────────────────────────────────────────────────────
kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -
kubectl label namespace "$NAMESPACE" name="$NAMESPACE" --overwrite

# ── 5. Helm repos ────────────────────────────────────────────────────────────
log "Adding Helm repos"
helm repo add bitnami   https://charts.bitnami.com/bitnami
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update

# ── 6. Ingress NGINX ─────────────────────────────────────────────────────────
log "Installing ingress-nginx"
helm upgrade --install ingress-nginx ingress-nginx/ingress-nginx \
    --namespace ingress-nginx --create-namespace \
    --set controller.service.type=LoadBalancer \
    --wait --timeout 3m

# ── 7. Kafka (Bitnami) ───────────────────────────────────────────────────────
log "Installing Kafka"
helm upgrade --install cb-kafka bitnami/kafka \
    --namespace "$NAMESPACE" \
    --set replicaCount=1 \
    --set kraft.enabled=true \
    --set controller.replicaCount=1 \
    --set broker.replicaCount=0 \
    --set listeners.client.protocol=PLAINTEXT \
    --set persistence.size=2Gi \
    --wait --timeout 5m

# ── 8. MongoDB (Bitnami) ─────────────────────────────────────────────────────
log "Installing MongoDB"
helm upgrade --install cb-mongodb bitnami/mongodb \
    --namespace "$NAMESPACE" \
    --set architecture=standalone \
    --set auth.rootPassword=cbsecret \
    --set auth.databases[0]=cb_ontology \
    --set auth.usernames[0]=cbuser \
    --set auth.passwords[0]=cbsecret \
    --set persistence.size=2Gi \
    --wait --timeout 5m

# ── 9. Secrets (placeholder — replace with Vault in production) ───────────────
log "Creating CB secrets"
kubectl create secret generic cb-secrets \
    --namespace "$NAMESPACE" \
    --from-literal=OPENAI_API_KEY="${OPENAI_API_KEY:-sk-placeholder}" \
    --from-literal=ANTHROPIC_API_KEY="${ANTHROPIC_API_KEY:-sk-ant-placeholder}" \
    --from-literal=GITHUB_TOKEN="${GITHUB_TOKEN:-ghp-placeholder}" \
    --from-literal=DATADOG_API_KEY="${DATADOG_API_KEY:-dd-placeholder}" \
    --from-literal=DATADOG_APP_KEY="${DATADOG_APP_KEY:-dd-app-placeholder}" \
    --dry-run=client -o yaml | kubectl apply -f -

# ── 10. Build and push service images ────────────────────────────────────────
REGISTRY="localhost:$REGISTRY_PORT"

build_and_push() {
    local service=$1
    local image="$REGISTRY/cb/$service:latest"
    log "Building $service -> $image"
    docker build -t "$image" "./$service"
    docker push "$image"
}

log "Building Java services (Gradle)"
./gradlew :cb-ontology-service:bootJar \
          :cb-scanner-adapter:bootJar \
          :cb-ai-agent:bootJar \
          :cb-pr-service:bootJar \
          :cb-notification-service:bootJar \
          :cb-audit-service:bootJar \
          :cb-gateway:bootJar \
          --parallel --build-cache

for svc in cb-ontology-service cb-scanner-adapter cb-ai-agent \
           cb-pr-service cb-notification-service cb-audit-service cb-gateway; do
    build_and_push "$svc"
done

log "Building Python embedder"
build_and_push "cb-python-embedder"

# ── 11. Deploy Kubernetes manifests ──────────────────────────────────────────
log "Applying Kubernetes manifests"
kubectl apply -f k8s/base/ -n "$NAMESPACE" --recursive

# ── 12. Wait for rollout ─────────────────────────────────────────────────────
log "Waiting for deployments to be ready..."
for svc in cb-ontology-service cb-scanner-adapter cb-ai-agent \
           cb-pr-service cb-python-embedder cb-gateway; do
    kubectl rollout status deployment/"$svc" -n "$NAMESPACE" --timeout=3m
done

# ── 13. Summary ──────────────────────────────────────────────────────────────
echo ""
log "==================================================="
log "Compliance Buddy is running on k3d!"
log "Gateway:    http://localhost:8080/api/"
log "Swagger UI: http://localhost:8080/api/swagger-ui.html"
log "Actuator:   http://localhost:8080/api/actuator/health"
log ""
log "Useful commands:"
log "  kubectl get pods -n $NAMESPACE"
log "  kubectl logs -n $NAMESPACE -l app=cb-ai-agent -f"
log "  kubectl port-forward svc/cb-gateway 8080:8080 -n $NAMESPACE"
log "==================================================="
