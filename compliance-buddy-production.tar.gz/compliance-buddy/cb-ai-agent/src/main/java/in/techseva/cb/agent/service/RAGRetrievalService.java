package in.techseva.cb.agent.service;

import in.techseva.cb.ontology.model.CbFix;
import in.techseva.cb.ontology.model.CbVulnerability;
import in.techseva.cb.ontology.repository.VectorSearchRepository;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * RAGRetrievalService
 *
 * 1. Calls the Python cb-embedder service to get a 3072-dim vector
 *    for the current vulnerability's JSON-LD representation.
 * 2. Executes MongoDB Atlas $vectorSearch to find top-k similar cb:Fix instances.
 * 3. Returns the list for injection into the LLM prompt.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RAGRetrievalService {

    private final VectorSearchRepository vectorSearchRepository;
    private final RestClient             embedderClient;
    private final MeterRegistry          meterRegistry;

    @Value("${cb.rag.top-k:5}")
    private int topK;

    @Value("${cb.rag.min-score:0.75}")
    private double minScore;

    /**
     * Retrieve semantically similar past fixes for the given vulnerability.
     *
     * @param vulnerability the cb:Vulnerability to find fixes for
     * @return ordered list of cb:Fix (most similar first), empty on failure
     */
    public List<CbFix> retrieveSimilarFixes(CbVulnerability vulnerability) {
        try {
            // 1. Generate embedding via Python cb-embedder
            float[] embedding = generateEmbedding(vulnerability);

            // 2. Vector search
            List<CbFix> results = vectorSearchRepository.findSimilarFixes(
                embedding, topK, minScore
            );

            log.info("[RAG] Retrieved {} similar fixes for vuln={} cwe={}",
                results.size(), vulnerability.id(), vulnerability.cweId());

            meterRegistry.counter("cb.rag.retrieval",
                "cweId", vulnerability.cweId(),
                "results", String.valueOf(results.size())
            ).increment();

            return results;

        } catch (Exception e) {
            log.warn("[RAG] Retrieval failed for {} — proceeding without prior context: {}",
                vulnerability.id(), e.getMessage());
            meterRegistry.counter("cb.rag.retrieval.failure",
                "cweId", vulnerability.cweId()).increment();
            return Collections.emptyList();
        }
    }

    /**
     * Call the Python cb-embedder microservice to generate a 3072-dim vector.
     * The embedder uses text-embedding-3-large via the OpenAI API.
     */
    @SuppressWarnings("unchecked")
    private float[] generateEmbedding(CbVulnerability vulnerability) {
        // Build a rich text representation — NOT just the raw JSON, but a
        // natural-language-friendly summary so the embedding captures semantic intent.
        String text = """
            Security vulnerability: %s
            Severity: %s
            Rule: %s
            File: %s
            Framework: %s
            Message: %s
            OWASP: %s
            """.formatted(
            vulnerability.cweId(),
            vulnerability.severity(),
            vulnerability.ruleKey(),
            vulnerability.affects() != null ? vulnerability.affects().filePath() : "unknown",
            vulnerability.affects() != null ? vulnerability.affects().framework() : "Spring Boot 4",
            vulnerability.message(),
            vulnerability.owaspCategory()
        );

        Map<String, Object> request = Map.of("text", text);

        Map<String, Object> response = embedderClient
            .post()
            .uri("/embed")
            .body(request)
            .retrieve()
            .body(Map.class);

        if (response == null || !response.containsKey("embedding")) {
            throw new IllegalStateException("Embedder returned null or missing 'embedding' field");
        }

        List<Number> embeddingList = (List<Number>) response.get("embedding");
        float[] vector = new float[embeddingList.size()];
        for (int i = 0; i < embeddingList.size(); i++) {
            vector[i] = embeddingList.get(i).floatValue();
        }

        log.debug("[RAG] Embedding generated: {} dimensions", vector.length);
        return vector;
    }
}
