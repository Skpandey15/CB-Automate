package in.techseva.cb.agent.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.techseva.cb.ontology.model.CbAuditEvent;
import in.techseva.cb.ontology.model.CbFix;
import in.techseva.cb.ontology.model.CbVulnerability;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * LLMPatchAgent
 *
 * Orchestrates the full AI remediation pipeline:
 *   1. Build structured prompt (system + vulnerability context + RAG fixes)
 *   2. Invoke LLM with Resilience4j circuit breaker + retry
 *   3. Parse cb:Fix from LLM response
 *   4. Publish to cb.fix.generated Kafka topic
 *   5. Emit audit event + Datadog metrics
 *
 * Resilience4j configuration in application.yml:
 *   - circuitbreaker: llm-agent (50% failure threshold, 30s wait)
 *   - retry: llm-agent (3 attempts, 5s exponential backoff)
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class LLMPatchAgent {

    private final ChatClient           chatClient;
    private final RAGRetrievalService  ragService;
    private final PromptBuilder        promptBuilder;
    private final ObjectMapper         objectMapper;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final MeterRegistry        meterRegistry;

    private static final String FIX_TOPIC   = "cb.fix.generated";
    private static final String AUDIT_TOPIC = "cb.audit.events";

    /**
     * Main entry point. Called by ScannerAdapterListener after ontology mapping.
     *
     * @param vulnerability fully-mapped cb:Vulnerability
     * @param priorFixes    top-k RAG-retrieved cb:Fix instances
     * @param correlationId distributed trace ID
     * @return generated CbFix or null on exhausted retries (circuit open)
     */
    @CircuitBreaker(name = "llm-agent", fallbackMethod = "llmFallback")
    @Retry(name = "llm-agent")
    public CbFix generateFix(CbVulnerability vulnerability,
                              List<CbFix> priorFixes,
                              String correlationId) {

        log.info("[LLMPatchAgent] Generating fix for {} correlationId={}",
            vulnerability.id(), correlationId);

        Timer.Sample timerSample = Timer.start(meterRegistry);

        try {
            // 1. Build the prompt
            String systemPrompt = promptBuilder.buildSystemPrompt();
            String userPrompt   = promptBuilder.buildUserPrompt(vulnerability, priorFixes);

            // 2. Invoke LLM
            ChatResponse response = chatClient
                .prompt()
                .messages(
                    new SystemMessage(systemPrompt),
                    new UserMessage(userPrompt)
                )
                .call()
                .chatResponse();

            String rawContent = response.getResult().getOutput().getContent();
            int    tokens     = response.getMetadata().getUsage() != null
                                ? (int) response.getMetadata().getUsage().getTotalTokens()
                                : 0;

            log.debug("[LLMPatchAgent] LLM responded with {} chars, {} tokens",
                rawContent.length(), tokens);

            // 3. Parse cb:Fix from LLM JSON-LD response
            CbFix fix = parseFix(rawContent, vulnerability, priorFixes, tokens, correlationId);

            // 4. Publish to Kafka
            kafkaTemplate.send(FIX_TOPIC, fix.id(), fix);

            // 5. Metrics
            timerSample.stop(meterRegistry.timer("cb.llm.inference.duration",
                "cweId", vulnerability.cweId(),
                "severity", vulnerability.severity(),
                "model", fix.llmModel()));

            meterRegistry.counter("cb.fix.generated",
                "cweId", vulnerability.cweId(),
                "severity", vulnerability.severity(),
                "strategy", fix.strategy()
            ).increment();

            meterRegistry.gauge("cb.fix.confidence",
                List.of(io.micrometer.core.instrument.Tag.of("cweId", vulnerability.cweId())),
                fix.confidence());

            // 6. Audit event
            publishAudit(CbAuditEvent.Action.FIX_GENERATED, fix.id(),
                "cb:Fix", "SUCCESS", correlationId,
                Map.of("confidence", fix.confidence(), "tokens", tokens));

            return fix;

        } catch (Exception e) {
            timerSample.stop(meterRegistry.timer("cb.llm.inference.duration",
                "outcome", "failure"));
            publishAudit(CbAuditEvent.Action.LLM_INVOKED, vulnerability.id(),
                "cb:Vulnerability", "FAILURE", correlationId,
                Map.of("error", e.getMessage()));
            throw e; // let Resilience4j handle retry / circuit break
        }
    }

    /**
     * Fallback invoked when circuit is OPEN or retries exhausted.
     * Publishes a FAILED audit event and Datadog counter.
     */
    @SuppressWarnings("unused")
    public CbFix llmFallback(CbVulnerability vulnerability,
                              List<CbFix> priorFixes,
                              String correlationId,
                              Throwable ex) {
        log.error("[LLMPatchAgent] Circuit OPEN / retries exhausted for {} — {}",
            vulnerability.id(), ex.getMessage());

        meterRegistry.counter("cb.fix.failed",
            "cweId", vulnerability.cweId(),
            "severity", vulnerability.severity(),
            "reason", ex.getClass().getSimpleName()
        ).increment();

        publishAudit(CbAuditEvent.Action.CIRCUIT_OPENED, vulnerability.id(),
            "cb:Vulnerability", "FAILURE", correlationId,
            Map.of("error", ex.getMessage(), "action", "ESCALATED"));

        return null; // upstream must handle null and escalate
    }

    // ─── Private helpers ────────────────────────────────────────────────────

    private CbFix parseFix(String rawContent,
                            CbVulnerability vuln,
                            List<CbFix> priorFixes,
                            int tokens,
                            String correlationId) {
        try {
            // Strip markdown fences if present
            String json = rawContent
                .replaceAll("(?s)```json\\s*", "")
                .replaceAll("(?s)```\\s*", "")
                .trim();

            @SuppressWarnings("unchecked")
            Map<String, Object> parsed = objectMapper.readValue(json, Map.class);

            String patchDiff = (String) parsed.getOrDefault("cb:patchDiff", "");
            String strategy  = (String) parsed.getOrDefault("cb:strategy", "UNKNOWN");
            double confidence= ((Number) parsed.getOrDefault("cb:confidence", 0.5)).doubleValue();
            String model     = (String) parsed.getOrDefault("cb:llmModel", "unknown");

            return CbFix.builder()
                .id(CbFix.buildId(vuln.cweId(), vuln.id(), 1))
                .vulnId(vuln.id())
                .patchDiff(patchDiff)
                .strategy(strategy)
                .confidence(confidence)
                .llmModel(model)
                .priorFixIds(priorFixes.stream().map(CbFix::id).toList())
                .status("GENERATED")
                .tokensUsed(tokens)
                .generatedAt(Instant.now())
                .build();

        } catch (Exception e) {
            log.warn("[LLMPatchAgent] JSON-LD parse failed — attempting raw diff extraction");
            // Fallback: treat entire content as raw diff
            return CbFix.builder()
                .id(CbFix.buildId(vuln.cweId(), vuln.id(), 1))
                .vulnId(vuln.id())
                .patchDiff(rawContent)
                .strategy("RAW_DIFF_FALLBACK")
                .confidence(0.3)
                .llmModel("unknown")
                .status("GENERATED")
                .tokensUsed(tokens)
                .generatedAt(Instant.now())
                .build();
        }
    }

    private void publishAudit(CbAuditEvent.Action action,
                               String targetId,
                               String targetType,
                               String outcome,
                               String correlationId,
                               Map<String, Object> details) {
        CbAuditEvent event = CbAuditEvent.builder()
            .id("cb:audit-" + UUID.randomUUID())
            .actor("cb-ai-agent")
            .action(action.name())
            .targetId(targetId)
            .targetType(targetType)
            .outcome(outcome)
            .details(details)
            .correlationId(correlationId)
            .timestamp(Instant.now())
            .build();
        kafkaTemplate.send(AUDIT_TOPIC, event.id(), event);
    }
}
