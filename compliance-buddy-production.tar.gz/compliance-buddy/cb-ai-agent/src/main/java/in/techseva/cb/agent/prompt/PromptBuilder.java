package in.techseva.cb.agent.prompt;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.techseva.cb.ontology.model.CbFix;
import in.techseva.cb.ontology.model.CbVulnerability;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * PromptBuilder
 *
 * Constructs the three-section LLM prompt:
 *   [System]  Role + strict JSON-LD output schema instruction
 *   [User]    Current cb:Vulnerability + cb:CodeArtifact as JSON-LD
 *             + top-k RAG-retrieved cb:Fix instances as JSON array
 *
 * The LLM is instructed to respond ONLY with a valid JSON-LD cb:Fix object.
 * Deviation triggers the parseFix fallback in LLMPatchAgent.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PromptBuilder {

    private final ObjectMapper objectMapper;

    // ─── System Prompt ───────────────────────────────────────────────────────

    public String buildSystemPrompt() {
        return """
            You are Compliance Buddy (CB), an expert Java security engineer specializing in
            OWASP Top 10 vulnerability remediation for Spring Boot 4 / Java 21 microservices
            built with Gradle Groovy DSL.

            Your task is to generate a production-ready remediation patch for a security
            vulnerability detected by SonarQube. You will be given:
              1. The vulnerable finding as a cb:Vulnerability JSON-LD object.
              2. Up to 5 similar past fixes as cb:Fix JSON-LD objects (RAG context).

            STRICT OUTPUT RULES:
            - Respond ONLY with a single valid JSON-LD object. No prose, no markdown fences.
            - The object MUST conform to the cb:Fix schema below.
            - cb:patchDiff MUST be a valid unified diff (--- a/file +++ b/file format).
            - cb:confidence MUST be a float between 0.0 and 1.0.
            - cb:strategy MUST describe the remediation pattern (e.g. PreparedStatement,
              ParameterizedQuery, OutputEncoding, SecureRandom, VaultSecret).
            - cb:llmModel MUST be set to the exact model name you are running on.

            REQUIRED OUTPUT SCHEMA:
            {
              "@context": "https://techseva.in/ontology/cb-context.jsonld",
              "@type": "cb:Fix",
              "@id": "cb:fix-{cweId}-{shortVulnId}-v1",
              "cb:patchDiff": "<unified diff string>",
              "cb:strategy": "<remediation strategy>",
              "cb:confidence": <0.0-1.0>,
              "cb:llmModel": "<model name>",
              "cb:explanation": "<1-3 sentence explanation of the fix>"
            }

            REMEDIATION GUIDELINES:
            - CWE-89 (SQL Injection):   Replace string concatenation with PreparedStatement
                                         or @Query with named parameters.
            - CWE-79 (XSS):             Apply HtmlUtils.htmlEscape() or Thymeleaf auto-escape.
            - CWE-78 (Command Injection): Use ProcessBuilder with argument lists, never Runtime.exec(String).
            - CWE-22 (Path Traversal):   Canonicalize paths with Path.toRealPath() and validate prefix.
            - CWE-798 (Hard-coded cred): Replace literal with @Value("${secret.key}") + Vault.
            - CWE-327 (Weak crypto):     Replace MD5/SHA1 with SHA-256+ or BCrypt for passwords.
            - CWE-918 (SSRF):            Validate URL against allowlist before HTTP client call.

            Always preserve existing business logic. Never remove error handling.
            Always add a comment: // CB-FIX: <cweId> — <strategy>
            """;
    }

    // ─── User Prompt ─────────────────────────────────────────────────────────

    public String buildUserPrompt(CbVulnerability vulnerability, List<CbFix> priorFixes) {
        try {
            String vulnJson  = objectMapper.writerWithDefaultPrettyPrinter()
                                           .writeValueAsString(vulnerability);
            String fixesJson = objectMapper.writerWithDefaultPrettyPrinter()
                                           .writeValueAsString(priorFixes);

            return """
                ## Current vulnerability to remediate

                %s

                ## Prior successful fixes for context (RAG — ordered by similarity score)

                %s

                ## Instructions

                Generate the cb:Fix JSON-LD object for the vulnerability above.
                Use the prior fixes as style and strategy references but adapt to the
                exact file path, line number, and code pattern in the current finding.
                Output ONLY the JSON-LD object. No prose.
                """.formatted(vulnJson, fixesJson);

        } catch (Exception e) {
            log.error("[PromptBuilder] Failed to serialize vulnerability to JSON", e);
            throw new IllegalStateException("Prompt serialization failed", e);
        }
    }
}
